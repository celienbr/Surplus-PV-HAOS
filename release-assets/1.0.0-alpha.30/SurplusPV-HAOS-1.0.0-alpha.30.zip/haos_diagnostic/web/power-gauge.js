/* Informational only: the controller snapshot is the source of accepted commands. */
(function(root){
 'use strict';
 const finite=n=>typeof n==='number'&&Number.isFinite(n);
 function powerGauge(s){
  if(!s || typeof s!=='object')return {value:null,detail:'État indisponible · état physique non vérifié'};
  if(s.error || s.startup_pending || s.dac_recovery?.pending)
   return {value:null,detail:'Commande non confirmée · état physique non vérifié'};
  const mode=s.mode, manual=mode==='MANUEL_REEL';
  const auto=['AUTO','AUTO_REEL'].includes(mode);
  const label=mode==='AUTO'?'Arrêt':mode==='AUTO_REEL'?'Consigne calculée':'Commande acceptée';
  if(!manual&&!auto)return {value:null,detail:'Mode inconnu · état physique non vérifié'};
  let n;
  if(mode==='AUTO')n=0;
  else if(manual){n=s.enabled===true?s.manual_percent:null;}
  else if(mode!=='AUTO'&&s.enabled===false)n=0;
  else if(mode!=='AUTO'&&s.enabled!==true)n=null;
  else n=finite(s.auto_requested_power_w)&&finite(s.max_power_w)&&s.max_power_w>0?100*s.auto_requested_power_w/s.max_power_w:null;
  return {value:finite(n)?Math.min(100,Math.max(0,n)):null,detail:label+' · état physique non vérifié'};
 }
 function render(s){
  const result=powerGauge(s),track=document.getElementById('power-track');
  if(!track)return;
  const value=result.value,display=value===null?'—':Number(value.toFixed(1)).toLocaleString('fr-CH')+' %';
  const manual=!!s&&s.mode==='MANUEL_REEL';
  document.getElementById('power-label').textContent=(manual?'Commande DAC : ':'Puissance demandée au boiler : ')+display;
  document.getElementById('power-fill').style.width=(value??0)+'%';
  document.getElementById('power-detail').textContent=result.detail;
  if(value===null){track.removeAttribute('aria-valuenow');track.setAttribute('aria-valuetext','Indisponible');}
  else {track.setAttribute('aria-valuenow',String(Number(value.toFixed(1))));track.setAttribute('aria-valuetext',display+' · '+result.detail);}
 }
 if(typeof module!=='undefined'&&module.exports)module.exports=powerGauge;
 if(root)root.renderPowerGauge=render;
})(typeof window==='undefined'?null:window);
